import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useLang } from './LangContext';

const IMG = {
  kitchen2: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/8c0c300cf_generated_image.png',
  kitchen3: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/ff173c8d8_generated_image.png',
  kitchen1: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/ebe5b562f_generated_image.png',
  kitchen4: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/00e618239_generated_image.png',
  sink: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/5241426a2_generated_image.png',
  table: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/d60514eec_generated_image.png',
  cabinet: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/d96cbf61c_generated_image.png',
  hood: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/64e3982e5_generated_image.png',
  shelving: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/f1fc3f520_generated_image.png'
};

const LOGO_DARK_FULL = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/03008a769_Capturadepantalla2026-08-11alas10817pm.png';

const PANELS = [
{ img: IMG.sink, dark: false, side: 'right', code: '01', cat: { en: 'Sinks', es: 'Tarjas' },
  name: { en: 'Stainless Steel Sinks', es: 'Tarjas de Acero Inoxidable' },
  desc: { en: 'Three-compartment, prep and hand-wash sinks built to code, with welded seams polished to a seamless finish.', es: 'Tarjas de tres compartimentos, preparación y lavamanos fabricadas a norma, con soldaduras pulidas a un acabado continuo.' } },
{ img: IMG.table, dark: false, side: 'left', code: '02', cat: { en: 'Work Tables', es: 'Mesas de Trabajo' },
  name: { en: 'Work Tables', es: 'Mesas de Trabajo' },
  desc: { en: 'Heavy-gauge work tables with undershelves and sound legs — built for daily commercial demand.', es: 'Mesas de calibre pesado con repisa inferior y patas reforzadas — fabricadas para el uso comercial diario.' } },
{ img: IMG.kitchen3, dark: true, side: 'right', code: '03', cat: { en: 'Complete Kitchens', es: 'Cocinas Completas' },
  name: { en: 'Engineered for High Volume', es: 'Diseñadas para Alto Volumen' },
  desc: { en: 'Robust cooking lines and exhaust systems designed to sustain continuous, high-output service without compromise.', es: 'Líneas de cocción y sistemas de extracción robustos diseñados para un servicio continuo de alto rendimiento.' } },
{ img: IMG.cabinet, dark: false, side: 'left', code: '04', cat: { en: 'Cabinets', es: 'Gabinetes' },
  name: { en: 'Prep Cabinets', es: 'Gabinetes de Preparación' },
  desc: { en: 'Sealed stainless cabinets with integrated worktops for hygienic, durable storage and prep.', es: 'Gabinetes de acero sellado con superficies integradas para almacenamiento y preparación higiénica.' } },
{ img: IMG.hood, dark: false, side: 'right', code: '05', cat: { en: 'Exhaust Hoods', es: 'Campanas' },
  name: { en: 'Exhaust Hoods', es: 'Campanas Extractoras' },
  desc: { en: 'Custom-fabricated hoods and ductwork engineered to your ventilation and compliance requirements.', es: 'Campanas y ductos fabricados a la medida según tus requerimientos de ventilación y normativa.' } },
{ img: IMG.kitchen4, dark: true, side: 'center', code: '06', cat: { en: 'Your Project', es: 'Tu Proyecto' },
  name: { en: 'Designed. Built. Delivered.', es: 'Diseñado. Fabricado. Entregado.' },
  desc: { en: 'Partner with PPC for your next complete kitchen build or custom equipment run.', es: 'Trabaja con PPC en tu próxima cocina completa o línea de equipo a la medida.' }, cta: true }];


const container = { hidden: {}, show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } } };
const item = { hidden: { opacity: 0, y: 30 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } } };

function Panel({ p }) {
  const ref = useRef(null);
  const { lang } = useLang();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['-7%', '7%']);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.14, 1.0, 1.14]);
  const center = p.side === 'center';

  const overlay = center ?
  'radial-gradient(circle at center, rgba(16,28,62,0.55) 0%, rgba(16,28,62,0.85) 100%)' :
  p.dark ?
  `linear-gradient(${p.side === 'left' ? 'to right' : 'to left'}, rgba(16,28,62,0.86) 0%, rgba(16,28,62,0.3) 46%, transparent 72%)` :
  `linear-gradient(${p.side === 'left' ? 'to right' : 'to left'}, rgba(255,255,255,0.94) 0%, rgba(255,255,255,0.5) 42%, transparent 66%)`;

  return (
    <section ref={ref} className="relative min-h-screen w-full overflow-hidden flex items-center">
      <div className="absolute inset-0 overflow-hidden">
        <motion.img src={p.img} alt={p.name[lang]} style={{ y, scale }}
        className="absolute inset-0 w-full h-[116%] -top-[8%] object-cover" />
      </div>
      <div className="absolute inset-0" style={{ background: overlay }} />

      <div className="relative z-10 w-full max-w-[1400px] mx-auto px-8 md:px-12">
        <motion.div variants={container} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.4 }}
        className={`max-w-xl ${center ? 'mx-auto text-center' : p.side === 'right' ? 'ml-auto text-right' : ''}`}>
          {p.cta &&
          <motion.div variants={item} className="mb-6 flex justify-center">
              <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/b168afeac_logo-white-.png" alt="PPC" className="h-16 w-auto object-contain" />
            </motion.div>
          }
          <motion.span variants={item} className="font-mono text-[11px] tracking-[0.3em] uppercase text-[#2a9d8f] block">
            {p.code} · {p.cat[lang]}
          </motion.span>
          <motion.h2 variants={item}
          className="font-bold leading-[1.02] tracking-[-0.02em] mt-4"
          style={{ fontSize: 'clamp(2rem, 5vw, 4.2rem)', fontFamily: "'Sarabun', ui-sans-serif, system-ui, sans-serif", color: p.dark ? '#ffffff' : '#101C3E' }}>
            {p.name[lang]}
          </motion.h2>
          <motion.p variants={item}
          className="font-body text-base md:text-lg leading-relaxed mt-5 max-w-md"
          style={{ color: p.dark ? 'rgba(255,255,255,0.82)' : 'rgba(51,65,85,1)', marginLeft: center ? 'auto' : undefined, marginRight: p.side === 'right' ? 0 : center ? 'auto' : undefined }}>
            {p.desc[lang]}
          </motion.p>
          {p.cta &&
          <motion.div variants={item} className="mt-9">
              <Link to="/contact"
            className="inline-block px-8 py-4 text-white font-mono text-[11px] tracking-[0.2em] uppercase transition-all duration-300 hover:shadow-2xl"
            style={{ background: '#2a9d8f' }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#1f7a6e'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#2a9d8f'}>
                {lang === 'es' ? 'Iniciar Proyecto' : 'Start a Project'}
              </Link>
            </motion.div>
          }
        </motion.div>
      </div>
    </section>);

}

export default function ImmersiveShowcase() {
  return (
    <div>
      {PANELS.map((p, i) => <Panel key={i} p={p} />)}
    </div>);

}