export default function MetaLabel({ children, className = '' }) {
  return (
    <span className={`font-mono text-[11px] tracking-[0.2em] uppercase text-slate-400 ${className}`}>
      [{children}]
    </span>
  );
}