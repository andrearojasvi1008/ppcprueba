import { motion } from 'framer-motion';
import { useLang } from './LangContext';

export default function IndustriesSection() {
  const { t } = useLang();
  const ind = t.industries;

  return (
    <section id="industries" className="py-24 bg-[#101C3E]">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="lg:col-span-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-6 h-px bg-[#2a9d8f]" />
              <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{ind.tag}</span>
            </div>
            <h2 className="font-bold text-white tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
            style={{ fontSize: 'clamp(1.8rem, 3vw, 2.8rem)' }}>
              {ind.h2}
            </h2>
            <p className="font-body text-slate-300 mt-4 text-base leading-relaxed">{ind.sub}</p>
          </motion.div>

          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-px bg-white/10">
            {ind.items.map((item, i) =>
            <motion.div
              key={item}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className="bg-[#101C3E] p-7 group hover:bg-[#0f2340] transition-colors duration-300 cursor-default border border-white/5 hover:border-[#2a9d8f]/30">
              
                <div className="flex items-start gap-4">
                  <span className="shrink-0 mt-0.5 font-mono text-[11px] tracking-widest text-[#2a9d8f]">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <p className="font-body text-slate-300 text-sm leading-relaxed group-hover:text-white transition-colors duration-300">
                    {item}
                  </p>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>);

}