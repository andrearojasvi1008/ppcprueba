import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Menu } from 'lucide-react';
import { useLang } from './LangContext';
import LangToggle from './LangToggle';

const LOGO_LIGHT = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/07480f69b_Capturadepantalla2026-08-11alas10754pm.png';
const LOGO_DARK = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/03008a769_Capturadepantalla2026-08-11alas10817pm.png';

export default function Layout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { t, lang } = useLang();
  const location = useLocation();

  const navItems = [
  { label: lang === 'es' ? 'Inicio' : 'Home', to: '/' },
  { label: t.nav.services, to: '/services' },
  { label: t.nav.products, to: '/products' },
  { label: t.nav.process, to: '/process' },
  { label: t.nav.about, to: '/about' },
  { label: t.nav.contact, to: '/contact' }];


  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-b border-slate-100">
        <div className="w-full md:px-10 h-20 flex items-center justify-between gap-4 my-5 px-6">
          <NavLink to="/" className="flex-shrink-0">
            <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/7affe48da_logo-pcc.png" alt="PPC" className="h-14 w-auto object-contain pr-12 my-10 pl-1" />
          </NavLink>

          <div className="hidden lg:flex items-center gap-6">
            {navItems.map((item) =>
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
              `font-mono text-[11px] tracking-widest uppercase transition-colors duration-200 ${
              isActive ? 'text-[#101C3E] border-b border-[#101C3E]' : 'text-slate-500 hover:text-[#101C3E]'}`

              }>
              
                {item.label}
              </NavLink>
            )}
            <LangToggle />
            <NavLink
              to="/contact"
              className="ml-2 px-6 py-2.5 bg-[#101C3E] text-white font-mono text-[11px] tracking-widest uppercase hover:bg-[#2a9d8f] transition-colors duration-300">
              
              {t.nav.cta}
            </NavLink>
          </div>

          <div className="flex items-center gap-3 lg:hidden">
            <LangToggle />
            <button onClick={() => setMenuOpen(true)} className="p-2">
              <Menu className="w-6 h-6 text-slate-700" />
            </button>
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {menuOpen &&
        <motion.div
          initial={{ opacity: 0, x: '100%' }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: '100%' }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
          className="fixed inset-0 z-[100] bg-[#101C3E] flex flex-col">
          
            <div className="flex items-center justify-between px-6 h-20 border-b border-white/10">
              <img src={LOGO_DARK} alt="PPC" className="h-14 w-auto object-contain" />
              <button onClick={() => setMenuOpen(false)} className="p-2">
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <div className="flex flex-col flex-1 justify-center px-8 gap-6">
              {navItems.map((item, i) =>
            <motion.div
              key={item.to}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.07 }}>
              
                  <NavLink
                to={item.to}
                end={item.to === '/'}
                onClick={() => setMenuOpen(false)}
                className={({ isActive }) =>
                `block text-left font-heading text-3xl font-light pb-6 border-b border-white/10 transition-colors ${
                isActive ? 'text-[#2a9d8f]' : 'text-white hover:text-[#2a9d8f]'}`

                }>
                
                    {item.label}
                  </NavLink>
                </motion.div>
            )}
              <NavLink
              to="/contact"
              onClick={() => setMenuOpen(false)}
              className="mt-4 px-8 py-4 bg-[#2a9d8f] text-white font-mono text-xs tracking-widest uppercase w-fit">
              
                {t.nav.cta}
              </NavLink>
            </div>
          </motion.div>
        }
      </AnimatePresence>

      <main className="pt-20">
        <Outlet />
      </main>
    </>);

}