export default function GridOverlay() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
      <div className="absolute inset-0 flex">
        {Array.from({ length: 13 }).map((_, i) => (
          <div
            key={i}
            className="flex-1 border-r border-border/40"
            style={{ borderWidth: '0 0.5px 0 0' }}
          />
        ))}
      </div>
    </div>
  );
}