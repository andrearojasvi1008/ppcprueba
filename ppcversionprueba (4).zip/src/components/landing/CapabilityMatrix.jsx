import { useState } from 'react';
import { motion } from 'framer-motion';
import { Code2, Shield, Zap, Layers } from 'lucide-react';
import MetaLabel from './MetaLabel';

const capabilities = [
  {
    icon: Code2,
    code: 'SYS_01',
    title: 'Custom Software Development',
    description: 'Bespoke application architecture tailored to your exact specifications — scalable, maintainable, and built to enterprise standards.',
  },
  {
    icon: Shield,
    code: 'SYS_02',
    title: 'Systems Integration',
    description: 'Seamless API orchestration and middleware solutions that unify disparate platforms into a single coherent operational layer.',
  },
  {
    icon: Zap,
    code: 'SYS_03',
    title: 'Performance Optimization',
    description: 'Deep-level profiling and refactoring of legacy systems to unlock maximum throughput with minimal resource overhead.',
  },
  {
    icon: Layers,
    code: 'SYS_04',
    title: 'Technical Consulting',
    description: 'Strategic advisory services to align your technology roadmap with business objectives and engineering best practices.',
  },
];

export default function CapabilityMatrix() {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  return (
    <section id="capabilities" className="relative py-32" style={{ background: '#F5F7FA' }}>
      <div className="max-w-[1440px] mx-auto px-6 md:px-12">
        <div className="mb-16 max-w-xl">
          <MetaLabel>MODULE_02 — CAPABILITY MATRIX</MetaLabel>
          <h2
            className="font-display font-bold mt-4 tracking-[-0.03em]"
            style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)', color: '#0A0A0B' }}
          >
            Core Services
          </h2>
          <p className="font-body text-slate-500 mt-4 text-base leading-relaxed">
            Four precision-engineered service pillars that define PPC's technical authority.
          </p>
        </div>

        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
          style={{ gap: '1px', background: '#e2e8f0' }}
        >
          {capabilities.map((cap, i) => {
            const Icon = cap.icon;
            const isHovered = hoveredIndex === i;
            return (
              <motion.div
                key={cap.code}
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
                className="relative bg-white p-8 cursor-default transition-all duration-500"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                {/* Top border highlight */}
                <div
                  className="absolute top-0 left-0 right-0 h-[2px] transition-all duration-500"
                  style={{
                    background: isHovered ? '#2a9d8f' : 'transparent',
                  }}
                />

                <div className="flex items-center justify-between mb-6">
                  <Icon
                    className="w-5 h-5 transition-colors duration-300"
                    style={{ color: isHovered ? '#2a9d8f' : '#94a3b8' }}
                  />
                  <span className="font-mono text-[10px] tracking-[0.2em]" style={{ color: '#cbd5e1' }}>
                    [{cap.code}]
                  </span>
                </div>

                <h3
                  className="font-display font-semibold text-lg mb-3 tracking-tight transition-colors duration-300"
                  style={{ color: isHovered ? '#1e3a5f' : '#0A0A0B' }}
                >
                  {cap.title}
                </h3>
                <p className="font-body text-slate-500 text-sm leading-relaxed">
                  {cap.description}
                </p>

                {isHovered && (
                  <div
                    className="absolute inset-0 pointer-events-none"
                    style={{ border: '1px solid rgba(42,157,143,0.15)', boxShadow: 'inset 0 0 30px rgba(42,157,143,0.03)' }}
                  />
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}