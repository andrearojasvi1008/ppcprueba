import { Link } from 'react-router-dom';
import { useLang } from './LangContext';

const LOGO_BLUE = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/03008a769_Capturadepantalla2026-08-11alas10817pm.png';

const navLinks = [
{ href: '/', es: 'Inicio', en: 'Home' },
{ href: '/services', es: 'Servicios', en: 'Services' },
{ href: '/products', es: 'Productos', en: 'Products' },
{ href: '/process', es: 'Proceso', en: 'Process' },
{ href: '/about', es: 'Nosotros', en: 'About' },
{ href: '/contact', es: 'Contacto', en: 'Contact' }];


export default function Footer() {
  const { t, lang } = useLang();
  const f = t.footer;
  const year = new Date().getFullYear();

  return (
    <footer style={{ background: '#101C3E' }}>
      {/* Big logo band — same bg so it bleeds seamlessly from the section above */}
      






      

      {/* Logo + divider band */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-12 pt-12 pb-8 flex items-center gap-6 border-b border-white/10 mb-8">
        <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/4874e34b0_ppc-logo-small.png" alt="PPC" className="h-8 w-auto object-contain opacity-80" />
        <div className="flex-1 h-px bg-white/10" />
      </div>

      {/* Info grid */}
      <div className="max-w-[1400px] mx-auto px-8 md:px-12 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pb-12 border-b border-white/10">
          <div>
            <p className="font-body text-slate-400 text-sm leading-relaxed">{f.tagline}</p>
          </div>
          <div>
            <h4 className="font-mono text-[11px] tracking-widest uppercase text-[#2a9d8f] mb-4">{f.whatWeDo}</h4>
            <ul className="space-y-2">
              {['AutoCAD Design Support', 'CNC Programming', 'Fabrication & Delivery', 'Production Support'].map((s) =>
              <li key={s} className="font-body text-sm text-slate-400">{s}</li>
              )}
            </ul>
          </div>
          <div>
            <h4 className="font-mono text-[11px] tracking-widest uppercase text-[#2a9d8f] mb-4">{f.nav}</h4>
            <ul className="space-y-2">
              {navLinks.map((link) =>
              <li key={link.href}>
                  <Link to={link.href} className="font-body text-sm text-slate-400 hover:text-white transition-colors duration-200">
                    {lang === 'es' ? link.es : link.en}
                  </Link>
                </li>
              )}
            </ul>
          </div>
        </div>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8">
          <span className="font-mono text-[11px] text-slate-500 tracking-wider">
            &copy; {year} Precision Programming Consulting. {f.rights}
          </span>
          <span className="font-mono text-[10px] text-slate-600 tracking-widest">[STATUS: ACTIVE]</span>
        </div>
      </div>
    </footer>);

}