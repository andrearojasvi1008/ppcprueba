import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';
import { useLang } from './LangContext';

const HERO_IMG = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/ebe5b562f_generated_image.png';
const LOGO_DARK_MONO = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/acb71a210_Capturadepantalla2026-08-11alas10812pm.png';

export default function ImmersiveHero() {
  const { t } = useLang();
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '28%']);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.18]);
  const opacity = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section ref={ref} className="relative h-screen w-full overflow-hidden bg-black">
      <motion.img src={HERO_IMG} alt="Stainless steel commercial kitchen"
      style={{ y, scale }} className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0"
      style={{ background: 'linear-gradient(to bottom, rgba(16,28,62,0.5) 0%, rgba(16,28,62,0.12) 35%, rgba(16,28,62,0.82) 100%)' }} />

      <motion.div style={{ opacity }} className="relative z-10 h-full flex flex-col justify-center max-w-[1400px] mx-auto px-8 md:px-12">
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.05 }}
        className="mb-8 inline-flex">
          <div className="px-4 py-3 hidden" style={{ background: '#13213a' }}>
            <img src={LOGO_DARK_MONO} alt="PPC" className="h-12 w-auto object-contain" />
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
        className="flex items-center gap-3 mb-6">
          <div className="w-10 h-px bg-[#2a9d8f]" />
          <span className="font-mono text-[11px] tracking-[0.3em] uppercase text-[#2a9d8f]">{t.hero.tag}</span>
        </motion.div>

        <motion.h1 initial={{ opacity: 0, y: 28 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.18 }}
        className="font-bold leading-[1.02] tracking-[-0.02em] text-white max-w-4xl"
        style={{ fontSize: 'clamp(2.6rem, 6vw, 5.5rem)', fontFamily: "'Sarabun', ui-sans-serif, system-ui, sans-serif" }}>
          {t.hero.h1a}{' '}{t.hero.h1b}
        </motion.h1>

        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.32 }}
        className="font-body text-slate-200 text-lg md:text-xl leading-relaxed max-w-xl mt-6">
          {t.hero.sub}
        </motion.p>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.46 }}
        className="flex flex-wrap gap-4 mt-9">
          <Link to="/contact"
          className="px-8 py-4 text-white font-mono text-[11px] tracking-[0.2em] uppercase transition-all duration-300 hover:shadow-2xl inline-block"
          style={{ background: '#2a9d8f' }}
          onMouseEnter={(e) => e.currentTarget.style.background = '#1f7a6e'}
          onMouseLeave={(e) => e.currentTarget.style.background = '#2a9d8f'}>
            {t.hero.cta1}
          </Link>
          <Link to="/services"
          className="px-8 py-4 border border-white/30 font-mono text-[11px] tracking-[0.2em] uppercase text-white transition-all duration-300 hover:bg-white hover:text-[#101C3E] inline-block">
            {t.hero.cta2}
          </Link>
        </motion.div>
      </motion.div>

      <motion.div style={{ opacity }} className="absolute bottom-7 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-white/55">
        <span className="font-mono text-[10px] tracking-[0.3em] uppercase">Scroll</span>
        <motion.span animate={{ y: [0, 8, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}>
          <ChevronDown className="w-4 h-4" />
        </motion.span>
      </motion.div>
    </section>);

}