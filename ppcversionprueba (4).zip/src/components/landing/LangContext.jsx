import { createContext, useContext, useState } from 'react';

const LangContext = createContext();

export const translations = {
  en: {
    nav: { services: 'Services', products: 'Products', industries: 'Industries', process: 'Process', about: 'About', contact: 'Contact', cta: 'Start Project' },
    hero: {
      tag: 'Kitchen Fabrication Specialists',
      h1a: 'Design, Programming',
      h1b: '& Fabrication',
      h1c: 'for Kitchen Equipment and Production Parts',
      sub: 'From AutoCAD drawings to laser-ready DXF files to finished fabricated parts — we help commercial kitchen manufacturers, custom residential projects, and production shops bring ideas into production.',
      cta1: 'Start My Project →',
      cta2: 'View Services',
      p1: { v: '15+', l: 'Years Experience' },
      p2: { v: '200+', l: 'Projects Delivered' },
      p3: { v: '1→∞', l: 'Any Quantity' },
    },
    pillars: [
      { num: '01', label: 'AutoCAD Design Support' },
      { num: '02', label: 'CNC Programming' },
      { num: '03', label: 'Fabrication & Delivery' },
    ],
    intro: {
      tag: 'What We Do',
      h2: 'Full-Service Support for Kitchen Fabrication',
      p1: 'Precision Programming & Consulting provides full-service support for kitchen fabrication and production parts. Whether you need help creating a drawing, converting an existing CAD file into a laser-ready DXF, or manufacturing and delivering finished parts, we can handle the process from start to finish.',
      p2: 'We specialize in commercial kitchen equipment, custom residential kitchen fabrication, and high-volume production parts.',
      tags: ['AutoCAD Design', 'CNC Programming', 'Fabrication & Delivery'],
    },
    services: {
      tag: 'Services', h2: 'What We Do at',
      items: [
        {
          code: 'SVC_01', title: 'AutoCAD Design & Drawing Support', tagline: 'Get the idea onto paper.',
          items: ['Create AutoCAD drawings from sketches, dimensions, or photos', 'Modify or improve existing drawings', 'Prepare shop drawings for fabrication', 'Convert rough concepts into production-ready files'],
        },
        {
          code: 'SVC_02', title: 'CNC Programming & DXF Preparation', tagline: 'Ready for the laser.',
          items: ['CAD to laser-ready DXF files', 'Clean geometry and corrected dimensions', 'Optimized for stainless steel and metal fabrication', 'Efficient nesting for production runs'],
        },
        {
          code: 'SVC_03', title: 'Fabrication of Kitchen Equipment & Parts', tagline: 'From file to finished part.',
          items: ['Commercial kitchen equipment and components', 'Custom residential kitchen metalwork', 'Stainless steel counters, shelves, hoods, brackets, and panels', 'Quantities from one custom piece to thousands of identical parts'],
        },
        {
          code: 'SVC_04', title: 'Delivery & Production Support', tagline: 'On time, every time.',
          items: ['Local delivery or shipping coordination', 'Repeat production orders', 'Ongoing support for manufacturers and fabrication shops', 'Long-term partnerships for recurring parts'],
        },
      ],
    },
    process: {
      tag: 'Process', h2: 'How It Works',
      sub: 'Five-step process from idea to finished part — we manage the entire workflow.',
      steps: [
        { num: '01', title: 'Tell Us What You Need', description: 'Send us a sketch, dimensions, an AutoCAD file, a PDF, or even a rough idea.' },
        { num: '02', title: 'We Design or Refine the Drawing', description: 'If needed, we create or clean up the AutoCAD drawing and prepare it for fabrication.' },
        { num: '03', title: 'We Program the File', description: 'We convert the drawing into a laser-ready DXF file optimized for your machine and material.' },
        { num: '04', title: 'We Fabricate the Parts', description: 'We manufacture the finished kitchen component or production part in the quantity you need.' },
        { num: '05', title: 'We Deliver It', description: 'We coordinate pickup, delivery, or repeat production so you have what you need, when you need it.' },
      ],
    },
    industries: {
      tag: 'Who We Serve', h2: 'Industries We Work With',
      sub: 'From one-off custom pieces to high-volume repeat production orders.',
      items: ['Commercial kitchen equipment manufacturers', 'Custom residential kitchen builders and fabricators', 'Restaurants and foodservice companies', 'Stainless steel and sheet metal shops', 'General contractors and builders', 'Manufacturers needing repeat production parts'],
    },
    about: {
      tag: 'About PPC', h2: 'Built to Bridge Design and Production',
      p1: 'Precision Programming & Consulting was built to bridge the gap between design and production. Too often, shops receive drawings that are incomplete, difficult to manufacture, or not ready for the laser.',
      p2: 'Whether you need a custom stainless steel kitchen hood, 100 production brackets, or help turning an idea into a real drawing, we make the process simple.',
      stats: [{ v: '3', l: 'Core Services' }, { v: '1+', l: 'Any Quantity' }, { v: '100%', l: 'End-to-End' }],
    },
    contact: {
      tag: 'Contact', h2: 'Start Your Project',
      sub: 'Whether you already have a drawing or need help creating one, we can take your project from concept to finished part.',
      fields: { name: 'NAME', company: 'COMPANY', email: 'EMAIL', qty: 'QUANTITY_NEEDED', notes: 'NOTES / DIMENSIONS / TIMELINE', upload: 'UPLOAD_FILE', projectType: 'PROJECT_TYPE' },
      placeholders: { name: 'Your name', company: 'Company name', email: 'your@email.com', qty: 'e.g. 1 custom piece or 500 units', notes: 'Describe your project, material, dimensions, or timeline...', upload: 'DXF, DWG, PDF, photo or sketch — optional' },
      types: ['AutoCAD Design', 'CNC Programming', 'Fabrication', 'Parts for Production', 'Laser-Cut Parts', 'Repeat Production'],
      laserOptions: ['Flat Parts', 'Precision-Cut Parts', 'Laser Cutting'],
      submit: 'Start My Project with',
      success: { h: 'Project Request Received', p: 'A PPC consultant will reach out within 24 hours to discuss your project.' },
    },
    products: {
      tag1: 'Products', h1: 'Stainless Steel Catalog',
      sub1: 'Standard and custom-manufactured stainless steel products for commercial and residential kitchens.',
      tag2: 'Complete Solutions', h2: 'Complete Commercial Kitchens',
      sub2: 'From individual components to fully designed, manufactured, and installed commercial kitchen projects.',
      note: 'We design, manufacture, and install complete commercial kitchen solutions — not just individual products. From layout planning to final installation.',
    },
    footer: { tagline: 'Design, programming, and fabrication for kitchen equipment and production parts.', whatWeDo: 'What We Do', nav: 'Navigation', rights: 'All rights reserved.' },
  },
  es: {
    nav: { services: 'Servicios', products: 'Productos', industries: 'Industrias', process: 'Proceso', about: 'Nosotros', contact: 'Contacto', cta: 'Iniciar Proyecto' },
    hero: {
      tag: 'Especialistas en Fabricación de Cocinas',
      h1a: 'Diseño, Programación',
      h1b: '& Fabricación',
      h1c: 'para Equipos de Cocina y Piezas de Producción',
      sub: 'Desde dibujos AutoCAD hasta archivos DXF listos para láser y piezas fabricadas terminadas — ayudamos a fabricantes de cocinas comerciales, proyectos residenciales y talleres de producción a llevar sus ideas a la realidad.',
      cta1: 'Iniciar Mi Proyecto →',
      cta2: 'Ver Servicios',
      p1: { v: '15+', l: 'Años de Experiencia' },
      p2: { v: '200+', l: 'Proyectos Entregados' },
      p3: { v: '1→∞', l: 'Cualquier Cantidad' },
    },
    pillars: [
      { num: '01', label: 'Diseño AutoCAD' },
      { num: '02', label: 'Programación CNC' },
      { num: '03', label: 'Fabricación & Entrega' },
    ],
    intro: {
      tag: 'Lo Que Hacemos',
      h2: 'Soporte Completo para Fabricación de Cocinas',
      p1: 'Precision Programming & Consulting ofrece soporte completo para fabricación de cocinas y piezas de producción. Ya sea que necesite ayuda creando un dibujo, convirtiendo un archivo CAD existente en un DXF listo para láser, o fabricando y entregando piezas terminadas, podemos manejar el proceso de principio a fin.',
      p2: 'Nos especializamos en equipos de cocina comercial, fabricación de cocinas residenciales personalizadas y piezas de producción de alto volumen.',
      tags: ['Diseño AutoCAD', 'Programación CNC', 'Fabricación & Entrega'],
    },
    services: {
      tag: 'Servicios', h2: 'Lo Que Hacemos en',
      items: [
        {
          code: 'SVC_01', title: 'Diseño AutoCAD y Soporte de Dibujo', tagline: 'Lleva tu idea al papel.',
          items: ['Crear dibujos AutoCAD desde bocetos, dimensiones o fotos', 'Modificar o mejorar dibujos existentes', 'Preparar dibujos de taller para fabricación', 'Convertir conceptos en archivos listos para producción'],
        },
        {
          code: 'SVC_02', title: 'Programación CNC y Preparación DXF', tagline: 'Listo para el láser.',
          items: ['CAD a archivos DXF listos para láser', 'Geometría limpia y dimensiones corregidas', 'Optimizado para acero inoxidable y fabricación metálica', 'Nesting eficiente para corridas de producción'],
        },
        {
          code: 'SVC_03', title: 'Fabricación de Equipos de Cocina y Piezas', tagline: 'Del archivo a la pieza terminada.',
          items: ['Equipos y componentes de cocina comercial', 'Metalistería residencial personalizada', 'Mostradores, repisas, campanas, soportes y paneles de acero inoxidable', 'Cantidades desde una pieza personalizada hasta miles de piezas idénticas'],
        },
        {
          code: 'SVC_04', title: 'Entrega y Soporte de Producción', tagline: 'A tiempo, siempre.',
          items: ['Entrega local o coordinación de envío', 'Órdenes de producción repetidas', 'Soporte continuo para fabricantes y talleres', 'Asociaciones a largo plazo para piezas recurrentes'],
        },
      ],
    },
    process: {
      tag: 'Proceso', h2: 'Cómo Funciona',
      sub: 'Proceso de cinco pasos desde la idea hasta la pieza terminada.',
      steps: [
        { num: '01', title: 'Cuéntanos Qué Necesitas', description: 'Envíanos un boceto, dimensiones, un archivo AutoCAD, un PDF o incluso una idea aproximada.' },
        { num: '02', title: 'Diseñamos o Refinamos el Dibujo', description: 'Si es necesario, creamos o limpiamos el dibujo AutoCAD y lo preparamos para fabricación.' },
        { num: '03', title: 'Programamos el Archivo', description: 'Convertimos el dibujo en un archivo DXF listo para láser, optimizado para tu máquina y material.' },
        { num: '04', title: 'Fabricamos las Piezas', description: 'Fabricamos el componente de cocina o pieza de producción terminada en la cantidad que necesitas.' },
        { num: '05', title: 'Lo Entregamos', description: 'Coordinamos la recolección, entrega o producción repetida para que tengas lo que necesitas, cuando lo necesitas.' },
      ],
    },
    industries: {
      tag: 'A Quién Servimos', h2: 'Industrias con las que Trabajamos',
      sub: 'Desde piezas únicas personalizadas hasta órdenes de producción de alto volumen.',
      items: ['Fabricantes de equipos de cocina comercial', 'Constructores y fabricantes de cocinas residenciales personalizadas', 'Restaurantes y empresas de servicios de alimentos', 'Talleres de acero inoxidable y lámina metálica', 'Contratistas generales y constructores', 'Fabricantes que necesitan piezas de producción repetida'],
    },
    about: {
      tag: 'Sobre PPC', h2: 'Construido para Unir Diseño y Producción',
      p1: 'Precision Programming & Consulting fue construido para cerrar la brecha entre el diseño y la producción. Con demasiada frecuencia, los talleres reciben dibujos incompletos, difíciles de fabricar o no listos para el láser.',
      p2: 'Ya sea que necesites una campana de cocina personalizada en acero inoxidable, 100 soportes de producción, o ayuda para convertir una idea en un dibujo real, hacemos el proceso simple.',
      stats: [{ v: '3', l: 'Servicios Core' }, { v: '1+', l: 'Cualquier Cantidad' }, { v: '100%', l: 'Integral' }],
    },
    contact: {
      tag: 'Contacto', h2: 'Inicia Tu Proyecto',
      sub: 'Ya sea que tengas un dibujo o necesites ayuda para crearlo, podemos llevar tu proyecto del concepto a la pieza terminada.',
      fields: { name: 'NOMBRE', company: 'EMPRESA', email: 'EMAIL', qty: 'CANTIDAD_NECESARIA', notes: 'NOTAS / DIMENSIONES / PLAZO', upload: 'SUBIR_ARCHIVO', projectType: 'TIPO_DE_PROYECTO' },
      placeholders: { name: 'Tu nombre', company: 'Nombre de la empresa', email: 'tu@email.com', qty: 'ej. 1 pieza o 500 unidades', notes: 'Describe tu proyecto, material, dimensiones o plazo...', upload: 'DXF, DWG, PDF, foto o boceto — opcional' },
      types: ['Diseño AutoCAD', 'Programación CNC', 'Fabricación', 'Piezas para Producción', 'Piezas de Corte Láser', 'Producción Repetida'],
      laserOptions: ['Piezas Planas', 'Piezas de Precisión', 'Corte Láser'],
      submit: 'Iniciar Mi Proyecto con',
      success: { h: 'Solicitud de Proyecto Recibida', p: 'Un consultor PPC se comunicará contigo en 24 horas para hablar de tu proyecto.' },
    },
    products: {
      tag1: 'Productos', h1: 'Catálogo de Acero Inoxidable',
      sub1: 'Productos estándar y fabricados a medida en acero inoxidable para cocinas comerciales y residenciales.',
      tag2: 'Soluciones Completas', h2: 'Cocinas Comerciales Completas',
      sub2: 'Desde componentes individuales hasta proyectos de cocina comercial completamente diseñados, fabricados e instalados.',
      note: 'Diseñamos, fabricamos e instalamos soluciones completas de cocina comercial — no solo productos individuales. Desde la planificación del diseño hasta la instalación final.',
    },
    footer: { tagline: 'Diseño, programación y fabricación para equipos de cocina y piezas de producción.', whatWeDo: 'Lo Que Hacemos', nav: 'Navegación', rights: 'Todos los derechos reservados.' },
  },
};

export function LangProvider({ children }) {
  const [lang, setLang] = useState('en');
  return (
    <LangContext.Provider value={{ lang, setLang, t: translations[lang] }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  return useContext(LangContext);
}