import { motion } from 'framer-motion';
import { useLang } from './LangContext';

const pillars = {
  en: [
  {
    num: '01',
    title: 'We Listen First',
    body: 'Before anything is programmed or fabricated, we listen to understand your exact need — the material, the quantity, the deadline, the end use. No guessing. No assumptions.'
  },
  {
    num: '02',
    title: 'Files That Actually Work',
    body: 'We have seen too many drawings that are impossible to cut — wrong tolerances, bad geometry, missing dimensions. Every file we deliver is clean, correct, and ready for production.'
  },
  {
    num: '03',
    title: 'One Partner, Full Pipeline',
    body: 'Most shops hand you off at every step. We handle design, programming, and fabrication under one roof — so nothing gets lost in translation between teams.'
  },
  {
    num: '04',
    title: 'Built for Repeat Work',
    body: 'We thrive on long-term relationships. When you need the same bracket next month or the same hood panel for the tenth time, we have your file, your specs, and your standards on record.'
  }],

  es: [
  {
    num: '01',
    title: 'Primero Escuchamos',
    body: 'Antes de programar o fabricar cualquier cosa, escuchamos para entender tu necesidad exacta — el material, la cantidad, el plazo, el uso final. Sin suposiciones.'
  },
  {
    num: '02',
    title: 'Archivos que Realmente Funcionan',
    body: 'Hemos visto demasiados dibujos imposibles de cortar — tolerancias incorrectas, geometría defectuosa, dimensiones faltantes. Cada archivo que entregamos está limpio, correcto y listo para producción.'
  },
  {
    num: '03',
    title: 'Un Solo Socio, Todo el Pipeline',
    body: 'La mayoría de los talleres te transfieren en cada paso. Nosotros manejamos diseño, programación y fabricación bajo un mismo techo — nada se pierde en la comunicación entre equipos.'
  },
  {
    num: '04',
    title: 'Construido para Trabajo Repetido',
    body: 'Prosperamos en relaciones a largo plazo. Cuando necesites el mismo soporte el mes que viene o el mismo panel por décima vez, tenemos tu archivo, tus especificaciones y tus estándares registrados.'
  }]

};

const LOGO = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/5a4cecdb6_PPC-blue.jpg';

const ABOUT_IMG = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/f8534dc4c_generated_image.png';

export default function WhyUsSection() {
  const { lang } = useLang();
  const items = pillars[lang];
  const heading = lang === 'es' ? 'Por Qué Trabajar con' : 'Why Work with';
  const tag = lang === 'es' ? 'Nuestro Compromiso' : 'Our Commitment';

  return (
    <section className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-16 max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-px bg-[#2a9d8f]" />
            <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{tag}</span>
          </div>
          <h2 className="font-bold text-[#0A0A0B] tracking-tight leading-tight [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif] flex items-center gap-4 flex-wrap"
          style={{ fontSize: 'clamp(2rem, 3.5vw, 3rem)' }}>
            {heading}
            <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/7affe48da_logo-pcc.png" alt="PPC" className="h-10 md:h-12 w-auto object-contain" />
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Pillars */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-px bg-slate-100">
            {items.map((p, i) =>
            <motion.div
              key={p.num}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-white p-8 group hover:bg-[#101C3E] transition-colors duration-400 cursor-default">
              
                <span className="font-mono text-[11px] tracking-widest text-[#2a9d8f] mb-4 block">[{p.num}]</span>
                <h3 className="font-heading font-bold text-lg text-[#0A0A0B] mb-3 group-hover:text-white transition-colors duration-300">
                  {p.title}
                </h3>
                <p className="font-body text-sm text-slate-500 leading-relaxed group-hover:text-slate-300 transition-colors duration-300">
                  {p.body}
                </p>
              </motion.div>
            )}
          </div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-5 sticky top-28">
            
            <div className="relative overflow-hidden" style={{ aspectRatio: '3/4' }}>
              <img src={ABOUT_IMG} alt="Precision fabrication" className="w-full h-full object-cover" />
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(16,28,62,0.7) 0%, transparent 50%)' }} />
              <div className="absolute bottom-6 left-6 right-6">
                <p className="font-display italic text-white text-xl leading-snug">
                  {lang === 'es' ?
                  '"Desde el boceto hasta la pieza terminada — sin transferencias, sin sorpresas."' :
                  '"From sketch to finished part — no handoffs, no surprises."'}
                </p>
                <div className="w-8 h-px bg-[#2a9d8f] mt-3" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

}