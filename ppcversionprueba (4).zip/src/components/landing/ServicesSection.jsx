import { useState } from 'react';
import { motion } from 'framer-motion';
import { PenTool, Settings, Wrench, Truck } from 'lucide-react';
import { useLang } from './LangContext';

const LOGO = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/5a4cecdb6_PPC-blue.jpg';

const ICONS = [PenTool, Settings, Wrench, Truck];
const COLORS = ['#101C3E', '#2a9d8f', '#101C3E', '#2a9d8f'];

const SERVICE_IMGS = [
'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/e6ca1a864_generated_image.png',
'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/f553947be_generated_image.png',
'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/d0ed12ded_generated_image.png',
'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/0a4d8386f_generated_image.png'];


export default function ServicesSection() {
  const [hovered, setHovered] = useState(null);
  const { t } = useLang();
  const s = t.services;

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-px bg-[#2a9d8f]" />
            <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{s.tag}</span>
          </div>
          <h2 className="font-bold text-[#0A0A0B] tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif] flex items-center gap-4"
          style={{ fontSize: 'clamp(2rem, 3.5vw, 3rem)' }}>
            {s.h2}
            <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/7affe48da_logo-pcc.png" alt="PPC" className="h-10 md:h-12 w-auto object-contain" />
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-100">
          {s.items.map((svc, i) => {
            const Icon = ICONS[i];
            const isHovered = hovered === i;
            return (
              <motion.div
                key={svc.code}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                className="relative bg-white overflow-hidden transition-all duration-300">
                
                {/* Top accent */}
                <div className="absolute top-0 left-0 right-0 h-[3px] transition-all duration-400"
                style={{ background: isHovered ? COLORS[i] : 'transparent' }} />

                {/* Image strip on hover */}
                <div className="relative overflow-hidden" style={{ height: isHovered ? '140px' : '0', transition: 'height 0.4s ease' }}>
                  <img src={SERVICE_IMGS[i]} alt={svc.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0" style={{ background: `linear-gradient(to bottom, transparent 40%, white)` }} />
                </div>

                <div className="p-8 md:p-10">
                  <div className="flex items-start justify-between mb-6">
                    <div className="w-12 h-12 flex items-center justify-center transition-colors duration-300"
                    style={{ background: isHovered ? COLORS[i] : '#F5F7FA' }}>
                      <Icon className="w-5 h-5 transition-colors duration-300"
                      style={{ color: isHovered ? '#fff' : COLORS[i] }} />
                    </div>
                    <span className="font-mono text-[10px] tracking-[0.2em] text-slate-300">[{svc.code}]</span>
                  </div>
                  <h3 className="font-bold text-xl mb-1 tracking-tight [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]" style={{ color: '#0A0A0B' }}>
                    {svc.title}
                  </h3>
                  <p className="font-mono text-[12px] tracking-wide mb-5" style={{ color: COLORS[i] }}>{svc.tagline}</p>
                  <ul className="space-y-2.5">
                    {svc.items.map((item) =>
                    <li key={item} className="flex items-start gap-3 text-slate-500 text-sm font-body leading-relaxed">
                        <span className="shrink-0 mt-1.5 w-1.5 h-1.5 rounded-full" style={{ background: COLORS[i] }} />
                        {item}
                      </li>
                    )}
                  </ul>
                </div>
              </motion.div>);

          })}
        </div>
      </div>
    </section>);

}