import { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload } from 'lucide-react';
import { useLang } from './LangContext';
import { base44 } from '@/api/base44Client';

const LOGO_WHITE = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/b168afeac_logo-white-.png';

export default function LeadTerminal() {
  const { t, lang } = useLang();
  const c = t.contact;

  const [formData, setFormData] = useState({ name: '', company: '', email: '', projectType: '', quantity: '', notes: '' });
  const [laserSub, setLaserSub] = useState('');
  const [file, setFile] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [focused, setFocused] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError('');
    try {
      let files = [];
      if (file) {
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        if (file_uri) files.push({ file_uri, filename: file.name });
      }

      const res = await base44.functions.invoke('submitLead', {
        name: formData.name,
        company: formData.company,
        email: formData.email,
        projectType: formData.projectType,
        laserSub,
        quantity: formData.quantity,
        notes: formData.notes,
        files
      });

      if (res?.data?.error) throw new Error(res.data.error);
      setSubmitted(true);
    } catch (err) {
      setSubmitError(err?.message || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const inputStyle = (key) => ({
    borderBottom: `2px solid ${focused === key ? '#2a9d8f' : '#e2e8f0'}`,
    color: '#0A0A0B'
  });
  const inputClass = "w-full bg-transparent pb-3 pt-1 font-body text-base outline-none transition-colors duration-300 placeholder:text-slate-300";

  return (
    <section id="contact" className="py-24 bg-[#F5F7FA]">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="lg:col-span-4 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-6 h-px bg-[#2a9d8f]" />
              <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{c.tag}</span>
            </div>
            <h2 className="font-bold text-[#0A0A0B] tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
            style={{ fontSize: 'clamp(1.8rem, 3vw, 2.8rem)' }}>
              {c.h2}
            </h2>
            <p className="font-body text-slate-500 text-base leading-relaxed">{c.sub}</p>
            <div className="space-y-4 pt-2">
              {['AutoCAD Design', 'CNC Programming', 'Fabrication & Delivery'].map((svc) =>
              <div key={svc} className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#2a9d8f]" />
                  <span className="font-body text-slate-600 text-sm">{svc}</span>
                </div>
              )}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.15 }} className="lg:col-span-8">
            <div className="bg-white border border-slate-100 shadow-sm">
              <div className="flex items-center gap-2 px-6 py-3.5 bg-[#101C3E]">
                <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <div className="w-2.5 h-2.5 rounded-full bg-[#2a9d8f]" />
                <span className="ml-3 font-mono text-[10px] tracking-widest text-white/40">PPC_PROJECT_INTAKE</span>
              </div>

              {submitted ?
              <div className="p-12 text-center">
                  <div className="w-14 h-14 mx-auto mb-5 border-2 border-[#2a9d8f] flex items-center justify-center">
                    <div className="w-4 h-4 bg-[#2a9d8f]" />
                  </div>
                  <h3 className="font-display font-semibold text-2xl text-[#0A0A0B]">{c.success.h}</h3>
                  <p className="font-body text-slate-500 mt-2">{c.success.p}</p>
                  <span className="font-mono text-[10px] text-slate-300 tracking-widest mt-4 inline-block">[STATUS: TRANSMITTED]</span>
                </div> :

              <form onSubmit={handleSubmit} className="p-6 md:p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    {[
                  { key: 'name', label: c.fields.name, ph: c.placeholders.name, type: 'text', req: true },
                  { key: 'company', label: c.fields.company, ph: c.placeholders.company, type: 'text', req: false },
                  { key: 'email', label: c.fields.email, ph: c.placeholders.email, type: 'email', req: true },
                  { key: 'quantity', label: c.fields.qty, ph: c.placeholders.qty, type: 'text', req: false }].
                  map((f) =>
                  <div key={f.key}>
                        <label className="font-mono text-[10px] tracking-[0.15em] text-slate-400 mb-2 block">{f.label}</label>
                        <input type={f.type} required={f.req} placeholder={f.ph}
                    value={formData[f.key]}
                    onChange={(e) => setFormData({ ...formData, [f.key]: e.target.value })}
                    onFocus={() => setFocused(f.key)} onBlur={() => setFocused(null)}
                    className={inputClass} style={inputStyle(f.key)} />
                    
                      </div>
                  )}
                  </div>

                  <div className="mb-6">
                    <label className="font-mono text-[10px] tracking-[0.15em] text-slate-400 mb-3 block">{c.fields.projectType}</label>
                    <div className="flex flex-wrap gap-2">
                      {c.types.map((pt) =>
                    <button key={pt} type="button"
                    onClick={() => {setFormData({ ...formData, projectType: pt });setLaserSub('');}}
                    className="px-4 py-2 font-mono text-[11px] tracking-wider border transition-all duration-200"
                    style={{
                      borderColor: formData.projectType === pt ? '#101C3E' : '#e2e8f0',
                      background: formData.projectType === pt ? '#101C3E' : 'transparent',
                      color: formData.projectType === pt ? '#fff' : '#64748b'
                    }}>
                      
                          {pt}
                        </button>
                    )}
                    </div>
                    {formData.projectType === (lang === 'es' ? 'Piezas de Corte Láser' : 'Laser-Cut Parts') &&
                  <div className="mt-3 flex flex-wrap gap-2">
                        {c.laserOptions.map((opt) =>
                    <button key={opt} type="button"
                    onClick={() => setLaserSub(opt)}
                    className="px-3 py-1.5 font-mono text-[10px] tracking-wider border transition-all duration-200"
                    style={{
                      borderColor: laserSub === opt ? '#2a9d8f' : '#e2e8f0',
                      background: laserSub === opt ? '#2a9d8f' : 'transparent',
                      color: laserSub === opt ? '#fff' : '#64748b'
                    }}>
                            {opt}
                          </button>
                    )}
                      </div>
                  }
                  </div>

                  <div className="mb-6">
                    <label className="font-mono text-[10px] tracking-[0.15em] text-slate-400 mb-2 block">{c.fields.upload}</label>
                    <label className="flex items-center gap-3 border border-dashed border-slate-200 p-4 cursor-pointer hover:border-[#2a9d8f] transition-colors duration-200">
                      <Upload className="w-4 h-4 text-slate-400" />
                      <span className="font-body text-sm text-slate-400">
                        {file ? file.name : c.placeholders.upload}
                      </span>
                      <input type="file" className="hidden" accept=".dxf,.dwg,.pdf,.jpg,.jpeg,.png"
                    onChange={(e) => setFile(e.target.files[0])} />
                    </label>
                  </div>

                  <div className="mb-8">
                    <label className="font-mono text-[10px] tracking-[0.15em] text-slate-400 mb-2 block">{c.fields.notes}</label>
                    <textarea rows={3} placeholder={c.placeholders.notes}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  onFocus={() => setFocused('notes')} onBlur={() => setFocused(null)}
                  className={`${inputClass} resize-none`} style={inputStyle('notes')} />
                  
                  </div>

                  {submitError &&
                  <p className="mb-4 font-mono text-[11px] text-red-600 tracking-wide">{submitError}</p>
                  }

                  <button type="submit" disabled={submitting}
                className="w-full py-4 text-white font-mono tracking-[0.25em] uppercase transition-all duration-300 flex items-center justify-center gap-3 px-3 text-[10px] disabled:opacity-60 disabled:cursor-wait"
                style={{ background: '#101C3E' }}
                onMouseEnter={(e) => { if (!submitting) e.currentTarget.style.background = '#2a9d8f'; }}
                onMouseLeave={(e) => { if (!submitting) e.currentTarget.style.background = '#101C3E'; }}>

                    {submitting ? (lang === 'es' ? 'TRANSMITIENDO…' : 'TRANSMITTING…') : c.submit}
                    <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/4874e34b0_ppc-logo-small.png" alt="PPC" className="h-5 w-auto object-contain" />
                  </button>
                </form>
              }
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

}