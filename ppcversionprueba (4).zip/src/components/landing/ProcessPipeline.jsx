import { motion } from 'framer-motion';
import { useLang } from './LangContext';

export default function ProcessPipeline() {
  const { t, lang } = useLang();
  const p = t.process;

  return (
    <section id="process" className="py-24 bg-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-16">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-px bg-[#2a9d8f]" />
            <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{p.tag}</span>
          </div>
          <h2 className="font-bold text-[#0A0A0B] tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
          style={{ fontSize: 'clamp(2rem, 3.5vw, 3rem)' }}>
            {p.h2}
          </h2>
          <p className="font-body text-slate-500 mt-3 text-base max-w-lg">{p.sub}</p>
        </motion.div>

        <div className="relative">
          {/* Vertical line */}
          <div className="hidden lg:block absolute left-[27px] top-8 bottom-8 w-[2px]"
          style={{ background: 'linear-gradient(to bottom, #101C3E, #2a9d8f)' }} />

          <div className="space-y-6">
            {p.steps.map((step, i) =>
            <motion.div
              key={step.num}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex items-start gap-8 group">
              
                <div
                className="shrink-0 w-14 h-14 flex items-center justify-center border-2 bg-white z-10 font-mono font-bold text-sm transition-all duration-300 group-hover:bg-[#101C3E] group-hover:text-white group-hover:border-[#101C3E]"
                style={{ borderColor: i < 3 ? '#101C3E' : '#2a9d8f', color: i < 3 ? '#101C3E' : '#2a9d8f' }}>
                
                  {step.num}
                </div>
                <div className="pt-3 pb-6 border-b border-slate-100 flex-1 group-hover:border-[#2a9d8f] transition-colors duration-300">
                  <h3 className="font-semibold text-xl text-[#0A0A0B] mb-1 [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]">{step.title}</h3>
                  <p className="font-body text-slate-500 text-sm leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>);

}