import { motion } from 'framer-motion';
import { useLang } from './LangContext';

const CNC_IMG = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/d25a39a2c_generated_image.png';
const CAD_IMG = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/e85c8b5e3_generated_image.png';

export default function IntroSection() {
  const { t } = useLang();
  const i = t.intro;

  return (
    <section className="py-0 bg-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          {/* Image panel */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-5 relative overflow-hidden"
            style={{ minHeight: '420px' }}>
            
            <img src={CNC_IMG} alt="CNC Laser Fabrication" className="w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, transparent 55%, #ffffff)' }} />
            <div className="absolute bottom-6 left-6">
              <span className="font-mono text-[10px] tracking-widest text-slate-400">[CNC_LASER_01]</span>
            </div>
          </motion.div>

          {/* Text panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
            className="lg:col-span-7 px-8 md:px-12 py-20 space-y-5 flex flex-col justify-center">
            
            <div className="flex items-center gap-3">
              <div className="w-6 h-px bg-[#2a9d8f]" />
              <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{i.tag}</span>
            </div>
            <h2 className="font-bold text-[#101C3E] leading-tight tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
            style={{ fontSize: 'clamp(1.8rem, 3vw, 2.8rem)' }}>
              {i.h2}
            </h2>
            <p className="font-body text-slate-600 text-base md:text-lg leading-relaxed">{i.p1}</p>
            <p className="font-body text-slate-600 text-base leading-relaxed">
              {i.p2.split(/(commercial kitchen equipment|cocina comercial|custom residential kitchen fabrication|cocinas residenciales personalizadas|high-volume production parts|piezas de producción de alto volumen)/gi).map((chunk, idx) => {
                const highlights = ['commercial kitchen equipment', 'cocina comercial', 'custom residential kitchen fabrication', 'cocinas residenciales personalizadas', 'high-volume production parts', 'piezas de producción de alto volumen'];
                return highlights.some((h) => h.toLowerCase() === chunk.toLowerCase()) ?
                <span key={idx} className="text-[#2a9d8f] font-medium">{chunk}</span> :
                <span key={idx}>{chunk}</span>;
              })}
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              {i.tags.map((tag) =>
              <span key={tag} className="font-mono text-[11px] tracking-widest uppercase px-4 py-2 border border-slate-200 text-slate-500 hover:border-[#2a9d8f] hover:text-[#2a9d8f] transition-colors duration-200 cursor-default">
                  {tag}
                </span>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

}