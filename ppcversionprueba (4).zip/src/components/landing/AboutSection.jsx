import { motion } from 'framer-motion';
import { useLang } from './LangContext';

const LOGO_URL = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/5a4cecdb6_PPC-blue.jpg';
const ABOUT_IMG = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/15d0c713b_generated_image.png';

export default function AboutSection() {
  const { t } = useLang();
  const a = t.about;

  return (
    <section id="about" className="py-0 bg-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-5 relative overflow-hidden"
            style={{ minHeight: '480px' }}>
            
            <img src={ABOUT_IMG} alt="Fabrication" className="w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, transparent 50%, white)' }} />
            {/* Overlay logo */}
            

            
          </motion.div>

          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-7 px-8 md:px-12 py-20 flex flex-col justify-center space-y-6">
            
            <div className="flex items-center gap-3">
              <div className="w-6 h-px bg-[#2a9d8f]" />
              <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{a.tag}</span>
            </div>
            <h2 className="font-bold text-[#0A0A0B] leading-tight tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
            style={{ fontSize: 'clamp(1.8rem, 3vw, 2.8rem)' }}>
              {a.h2}
            </h2>
            <p className="font-body text-slate-500 text-base leading-relaxed">{a.p1}</p>
            <p className="font-body text-slate-500 text-base leading-relaxed">{a.p2}</p>

            <div className="grid grid-cols-3 gap-6 pt-4 border-t border-slate-100">
              {a.stats.map((stat) =>
              <div key={stat.l}>
                  <div className="font-display font-bold text-3xl" style={{ color: '#101C3E' }}>{stat.v}</div>
                  <div className="font-mono text-[11px] tracking-widest uppercase text-[#2a9d8f] mt-1">{stat.l}</div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

}