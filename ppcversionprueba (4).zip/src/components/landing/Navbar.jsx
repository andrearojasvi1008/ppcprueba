import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Menu } from 'lucide-react';
import { useLang } from './LangContext';
import LangToggle from './LangToggle';

const LOGO_URL = 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/5a4cecdb6_PPC-blue.jpg';

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { t } = useLang();

  const navItems = [
    { label: t.nav.services, href: '#services' },
    { label: t.nav.industries, href: '#industries' },
    { label: t.nav.process, href: '#process' },
    { label: t.nav.about, href: '#about' },
    { label: t.nav.contact, href: '#contact' },
  ];

  const scrollTo = (href) => {
    setMenuOpen(false);
    setTimeout(() => {
      const el = document.querySelector(href);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-b border-slate-100">
        <div className="max-w-[1400px] mx-auto px-6 md:px-10 h-20 flex items-center justify-between gap-4">
          <a href="#" className="flex-shrink-0">
            <img src={LOGO_URL} alt="PPC" className="h-14 w-auto object-contain" />
          </a>

          <div className="hidden lg:flex items-center gap-6">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => scrollTo(item.href)}
                className="font-mono text-[11px] tracking-widest uppercase text-slate-500 hover:text-[#101C3E] transition-colors duration-200"
              >
                {item.label}
              </button>
            ))}
            <LangToggle />
            <button
              onClick={() => scrollTo('#contact')}
              className="ml-2 px-6 py-2.5 bg-[#101C3E] text-white font-mono text-[11px] tracking-widest uppercase hover:bg-[#2a9d8f] transition-colors duration-300"
            >
              {t.nav.cta}
            </button>
          </div>

          <div className="flex items-center gap-3 lg:hidden">
            <LangToggle />
            <button onClick={() => setMenuOpen(true)} className="p-2">
              <Menu className="w-6 h-6 text-slate-700" />
            </button>
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-0 z-[100] bg-[#101C3E] flex flex-col"
          >
            <div className="flex items-center justify-between px-6 h-20 border-b border-white/10">
              <img src={LOGO_URL} alt="PPC" className="h-12 w-auto object-contain" />
              <button onClick={() => setMenuOpen(false)} className="p-2">
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <div className="flex flex-col flex-1 justify-center px-8 gap-8">
              {navItems.map((item, i) => (
                <motion.button
                  key={item.label}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.07 }}
                  onClick={() => scrollTo(item.href)}
                  className="text-left font-display text-3xl font-light text-white hover:text-[#2a9d8f] transition-colors border-b border-white/10 pb-6"
                >
                  {item.label}
                </motion.button>
              ))}
              <button
                onClick={() => scrollTo('#contact')}
                className="mt-4 px-8 py-4 bg-[#2a9d8f] text-white font-mono text-xs tracking-widest uppercase w-fit"
              >
                {t.nav.cta}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}