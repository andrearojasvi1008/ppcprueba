import { motion } from 'framer-motion';
import { useLang } from './LangContext';

const PROJECTS = [
  { src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/a0fbdd1ca_generated_image.png', en: 'Residential Kitchens', es: 'Cocinas Residenciales', code: 'KTC_01' },
  { src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/0b3ca0f0c_generated_image.png', en: 'Restaurant Kitchens', es: 'Cocinas de Restaurante', code: 'KTC_02' },
  { src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/f77694895_generated_image.png', en: 'Hotel Kitchens', es: 'Cocinas de Hotel', code: 'KTC_03' },
  { src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/b0dfbee53_generated_image.png', en: 'Institutional Kitchens', es: 'Cocinas Institucionales', code: 'KTC_04' },
  { src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/337922ec8_generated_image.png', en: 'Cafeterias', es: 'Cafeterías', code: 'KTC_05' },
  { src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/80713f3be_generated_image.png', en: 'Outdoor Kitchen Pods', es: 'Cápsulas de Cocina al Aire Libre', code: 'KTC_06' },
];

export default function CommercialKitchens() {
  const { t, lang } = useLang();
  const p = t.products;

  return (
    <section id="commercial-kitchens" className="py-24 bg-[#F5F7FA] overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-14 max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-px bg-[#2a9d8f]" />
            <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{p.tag2}</span>
          </div>
          <h2 className="font-bold text-[#0A0A0B] tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
          style={{ fontSize: 'clamp(2rem, 3.5vw, 3rem)' }}>
            {p.h2}
          </h2>
          <p className="font-body text-slate-500 text-base mt-4 leading-relaxed">{p.sub2}</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-slate-100">
          {PROJECTS.map((proj, i) =>
          <motion.div
            key={proj.code}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            className="bg-white group overflow-hidden cursor-default">
            
            <div className="relative overflow-hidden" style={{ aspectRatio: '4/3' }}>
              <img
              src={proj.src}
              alt={proj[lang]}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              
              <div className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
              style={{ background: 'linear-gradient(to top, rgba(16,28,62,0.8) 0%, transparent 55%)' }} />
              
              <span className="absolute top-3 right-3 font-mono text-[9px] tracking-widest text-white/60 bg-black/20 px-2 py-1 backdrop-blur-sm">
                [{proj.code}]
              </span>
            </div>
            <div className="p-6">
              <h3 className="font-bold text-base tracking-tight [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]" style={{ color: '#0A0A0B' }}>
                {proj[lang]}
              </h3>
              <div className="w-8 h-px bg-[#2a9d8f] mt-2 group-hover:w-16 transition-all duration-400" />
            </div>
          </motion.div>
          )}
        </div>
      </div>
    </section>
  );
}