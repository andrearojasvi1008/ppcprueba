import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLang } from './LangContext';

const PROJECTS = [
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/0e4649dda_generated_image.png', en: 'Kitchen Hood', es: 'Campana Industrial', code: 'PRJ_01' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/01a452ee4_generated_image.png', en: 'Prep Counter Unit', es: 'Módulo de Preparación', code: 'PRJ_02' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/6e74cf2a6_generated_image.png', en: 'Wall Shelving', es: 'Repisas de Pared', code: 'PRJ_03' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/2053839c9_generated_image.png', en: 'Refrigerated Prep Table', es: 'Mesa de Preparación Refrigerada', code: 'PRJ_04' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/f6f7537d8_generated_image.png', en: 'Three-Compartment Sink', es: 'Tarja de Tres Compartimentos', code: 'PRJ_05' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/32d55244b_generated_image.png', en: 'Outdoor Kitchen Pod', es: 'Módulo de Cocina Exterior', code: 'PRJ_06' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/bd498d01d_generated_image.png', en: 'Outdoor Kitchen Island', es: 'Isla de Cocina Exterior', code: 'PRJ_07' }];


export default function GallerySection() {
  const { lang } = useLang();
  const [index, setIndex] = useState(0);
  const total = PROJECTS.length;

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % total), 5000);
    return () => clearInterval(id);
  }, []);

  const tag = lang === 'es' ? 'Galería de Trabajos' : 'Work Gallery';
  const title = lang === 'es' ? 'Del Diseño al Producto' : 'From Design to Product';
  const caption = lang === 'es' ? 'Cada proyecto empieza con un plano técnico y se transforma en un producto de acero inoxidable de alta calidad.' : 'Every project begins with a technical drawing and transforms into a high-quality stainless steel product.';
  const leftLabel = lang === 'es' ? 'Plano CAD' : 'CAD Drawing';
  const rightLabel = lang === 'es' ? 'Producto Terminado' : 'Finished Product';

  const p = PROJECTS[index];

  return (
    <section className="py-24 bg-[#F5F7FA] overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-12 max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-px bg-[#2a9d8f]" />
            <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{tag}</span>
          </div>
          <h2 className="font-bold text-[#0A0A0B] tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]"
          style={{ fontSize: 'clamp(1.8rem, 3vw, 2.8rem)' }}>
            {title}
          </h2>
          <p className="font-body text-slate-500 text-base mt-4 leading-relaxed">{caption}</p>
        </motion.div>

        {/* Stage */}
        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: 'easeInOut' }}
              className="relative overflow-hidden"
              style={{ aspectRatio: '16/9' }}>
              
              <img src={p.src} alt={p[lang]} className="w-full h-full object-cover" />

              {/* End labels */}
              <div className="absolute top-4 left-4 font-mono text-[10px] tracking-widest text-[#e0e8f7] bg-[#0d1b37]/50 px-2 py-1 backdrop-blur-sm">
                [01] {leftLabel.toUpperCase()}
              </div>
              <div className="absolute top-4 right-4 font-mono text-[10px] tracking-widest text-[#101C3E] bg-white/70 px-2 py-1 backdrop-blur-sm">
                [02] {rightLabel.toUpperCase()}
              </div>

              {/* Bottom caption */}
              <div className="absolute bottom-0 left-0 right-0 p-6 flex items-end justify-between"
              style={{ background: 'linear-gradient(to top, rgba(16,28,62,0.65), transparent)' }}>
                <div>
                  <span className="font-mono text-[10px] tracking-widest text-[#2a9d8f] block mb-1">{p.code}</span>
                  <span className="text-xl md:text-2xl text-white [font-family:'JetBrains_Mono',_ui-monospace,_SFMono-Regular,_Menlo,_Monaco,_Consolas,_monospace] font-normal">{p[lang]}</span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Minimal pagination */}
        <div className="mt-8 flex items-center justify-center gap-3">
          {PROJECTS.map((_, i) =>
          <button key={i} onClick={() => setIndex(i)} aria-label={`Project ${i + 1}`}
          className="h-1 rounded-full transition-all duration-500"
          style={{ width: i === index ? 32 : 10, background: i === index ? '#101C3E' : 'rgba(16,28,62,0.25)' }} />
          )}
        </div>
      </div>
    </section>);

}