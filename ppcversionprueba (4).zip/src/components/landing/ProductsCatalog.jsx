import { motion } from 'framer-motion';
import { useLang } from './LangContext';

const PRODUCTS = [
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/8e86cbd25_generated_image.png', en: 'Stainless Steel Tables', es: 'Mesas de Acero Inoxidable', code: 'PRD_01' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/d29b3db25_generated_image.png', en: 'Wall Shelving', es: 'Repisas de Pared', code: 'PRD_02' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/f64d7807f_generated_image.png', en: 'Sinks & Wash Stations', es: 'Fregaderos y Estaciones de Lavado', code: 'PRD_03' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/279e32ad3_generated_image.png', en: 'Storage Cabinets', es: 'Gabinetes de Almacenaje', code: 'PRD_04' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/241498703_generated_image.png', en: 'Exhaust Hoods', es: 'Campanas Extractoras', code: 'PRD_05' },
{ src: 'https://media.base44.com/images/public/6a27524c36ed67b8975e754a/a0ce0989c_generated_image.png', en: 'Counter Units', es: 'Módulos de Mostrador', code: 'PRD_06' }];


export default function ProductsCatalog() {
  const { t, lang } = useLang();
  const p = t.products;

  return (
    <section id="products" className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-8 md:px-12">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="mb-14 max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-6 h-px bg-[#2a9d8f]" />
            <span className="font-mono text-[11px] tracking-[0.25em] uppercase text-[#2a9d8f]">{p.tag1}</span>
          </div>
          <h2 className="font-bold text-[#0A0A0B] tracking-[-0.03em] [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif] flex items-center gap-3 flex-wrap"
          style={{ fontSize: 'clamp(2rem, 3.5vw, 3rem)' }}>
            {lang === 'es' ?
            <>
                <span>Catálogo de Acero Inoxidable</span>
                <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/4874e34b0_ppc-logo-small.png" alt="PPC" className="h-8 md:h-10 w-auto object-contain inline-block" />
              </> :

            <>
                <span>Stainless Steel</span>
                <img src="https://media.base44.com/images/public/6a27524c36ed67b8975e754a/7affe48da_logo-pcc.png" alt="PPC" className="h-8 md:h-10 w-auto object-contain inline-block" />
                <span>Catalog</span>
              </>
            }
          </h2>
          <p className="font-body text-slate-500 text-base mt-4 leading-relaxed">{p.sub1}</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-slate-100">
          {PRODUCTS.map((prod, i) =>
          <motion.div
            key={prod.code}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            className="bg-white group overflow-hidden cursor-default">
            
            <div className="relative overflow-hidden" style={{ aspectRatio: '4/3' }}>
              <img
                src={prod.src}
                alt={prod[lang]}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              
              <div className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
              style={{ background: 'linear-gradient(to top, rgba(16,28,62,0.8) 0%, transparent 55%)' }} />
              
              <span className="absolute top-3 right-3 font-mono text-[9px] tracking-widest text-white/60 bg-black/20 px-2 py-1 backdrop-blur-sm">
                [{prod.code}]
              </span>
            </div>
            <div className="p-6">
              <h3 className="font-bold text-base tracking-tight [font-family:'Sarabun',_ui-sans-serif,_system-ui,_sans-serif]" style={{ color: '#0A0A0B' }}>
                {prod[lang]}
              </h3>
              <div className="w-8 h-px bg-[#2a9d8f] mt-2 group-hover:w-16 transition-all duration-400" />
            </div>
          </motion.div>
          )}
        </div>
      </div>
    </section>);

}