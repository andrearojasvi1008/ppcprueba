import { useLang } from './LangContext';
import { motion } from 'framer-motion';

export default function LangToggle({ dark = false }) {
  const { lang, setLang } = useLang();

  return (
    <div className={`flex items-center gap-1 rounded-sm p-0.5 ${dark ? 'bg-white/10' : 'bg-slate-100'}`}>
      {['en', 'es'].map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          className="relative px-3 py-1.5 font-mono text-[10px] tracking-widest uppercase transition-colors duration-200"
          style={{ color: lang === l ? (dark ? '#fff' : '#1e3a5f') : (dark ? 'rgba(255,255,255,0.4)' : '#94a3b8') }}
        >
          {lang === l && (
            <motion.div
              layoutId="langPill"
              className="absolute inset-0 rounded-sm"
              style={{ background: dark ? '#2a9d8f' : '#1e3a5f' }}
              transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
            />
          )}
          <span className="relative z-10" style={{ color: lang === l ? '#fff' : undefined }}>{l}</span>
        </button>
      ))}
    </div>
  );
}