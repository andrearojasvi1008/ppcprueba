import ImmersiveHero from '../components/landing/ImmersiveHero';
import ImmersiveShowcase from '../components/landing/ImmersiveShowcase';
import Footer from '../components/landing/Footer';

export default function Home() {
  return (
    <div className="bg-white text-foreground antialiased">
      <ImmersiveHero />
      <ImmersiveShowcase />
      <Footer />
    </div>
  );
}