import ProductsCatalog from '../components/landing/ProductsCatalog';
import CommercialKitchens from '../components/landing/CommercialKitchens';
import Footer from '../components/landing/Footer';

export default function Products() {
  return (
    <div className="min-h-screen bg-white text-foreground antialiased">
      <ProductsCatalog />
      <CommercialKitchens />
      <Footer />
    </div>
  );
}