import ServicesSection from '../components/landing/ServicesSection';
import GallerySection from '../components/landing/GallerySection';
import Footer from '../components/landing/Footer';

export default function Services() {
  return (
    <div className="min-h-screen bg-white text-foreground antialiased">
      <ServicesSection />
      <GallerySection />
      <Footer />
    </div>
  );
}