import LeadTerminal from '../components/landing/LeadTerminal';
import Footer from '../components/landing/Footer';

export default function Contact() {
  return (
    <div className="min-h-screen bg-white text-foreground antialiased">
      <LeadTerminal />
      <Footer />
    </div>
  );
}