import AboutSection from '../components/landing/AboutSection';
import WhyUsSection from '../components/landing/WhyUsSection';
import Footer from '../components/landing/Footer';

export default function About() {
  return (
    <div className="min-h-screen bg-white text-foreground antialiased">
      <AboutSection />
      <WhyUsSection />
      <Footer />
    </div>
  );
}