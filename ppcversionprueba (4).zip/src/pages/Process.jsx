import ProcessPipeline from '../components/landing/ProcessPipeline';
import IndustriesSection from '../components/landing/IndustriesSection';
import Footer from '../components/landing/Footer';

export default function Process() {
  return (
    <div className="min-h-screen bg-white text-foreground antialiased">
      <ProcessPipeline />
      <IndustriesSection />
      <Footer />
    </div>
  );
}