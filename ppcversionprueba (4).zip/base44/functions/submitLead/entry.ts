import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

const RECIPIENT = 'ppcstainless@hotmail.com';

export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const { name, company, email, projectType, laserSub, quantity, notes, files } = body;

    if (!name || !email) {
      return Response.json({ error: 'Name and email are required.' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);

    // Build a readable email body from every submitted field.
    const rows = [
      ['Name', name],
      ['Company', company],
      ['Email', email],
      ['Project Type', projectType],
      ['Laser-Cut Sub-Type', laserSub],
      ['Quantity', quantity],
      ['Notes', notes]
    ];

    const textBody = [
      'New project inquiry submitted from the PPC website.',
      '',
      ...rows.map(([k, v]) => `${k}: ${v && String(v).trim() ? v : '—'}`)
    ].join('\n');

    const htmlRows = rows.map(([k, v]) =>
      `<tr><td style="padding:6px 12px 6px 0;color:#64748b;font-family:Inter,Arial,sans-serif;font-size:13px;vertical-align:top;white-space:nowrap">${k}</td>` +
      `<td style="padding:6px 0;color:#0A0A0B;font-family:Inter,Arial,sans-serif;font-size:14px;vertical-align:top">${v && String(v).trim() ? String(v).replace(/</g, '&lt;').replace(/>/g, '&gt;') : '—'}</td></tr>`
    ).join('');

    const htmlBody =
      `<div style="max-width:560px;margin:0 auto">` +
      `<p style="font-family:Inter,Arial,sans-serif;font-size:14px;color:#0A0A0B;margin:0 0 18px">A new project inquiry was submitted from the PPC website.</p>` +
      `<table style="border-collapse:collapse;width:100%">${htmlRows}</table>` +
      `<p style="font-family:'JetBrains Mono',monospace;font-size:11px;color:#94a3b8;margin-top:24px;letter-spacing:0.1em">[STATUS: TRANSMITTED]</p>` +
      `</div>`;

    // Resolve attachments: turn private file_uris into short-lived signed URLs the mailer can fetch.
    let attachments = [];
    if (Array.isArray(files) && files.length) {
      for (const f of files) {
        if (!f || !f.file_uri) continue;
        try {
          const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
            file_uri: f.file_uri,
            expires_in: 300
          });
          if (signed && signed.signed_url) {
            attachments.push({
              filename: f.filename || (f.file_uri.split('/').pop() || 'attachment'),
              file_url: signed.signed_url
            });
          }
        } catch (_e) {
          // Skip files that cannot be signed; still send the email with the rest of the data.
        }
      }
    }

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: RECIPIENT,
      subject: `New Project Inquiry — ${name}`,
      html: htmlBody,
      text: textBody,
      attachments: attachments.length ? attachments : undefined
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message || 'Failed to send inquiry.' }, { status: 500 });
  }
}